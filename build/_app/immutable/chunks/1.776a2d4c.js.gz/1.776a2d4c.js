import{default as t}from"../entry/error.svelte.9a967867.js";export{t as component};
