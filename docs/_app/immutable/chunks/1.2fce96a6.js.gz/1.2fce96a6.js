import{default as t}from"../entry/error.svelte.5964f91c.js";export{t as component};
