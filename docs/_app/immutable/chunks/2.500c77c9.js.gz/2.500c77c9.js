import{default as t}from"../entry/_page.svelte.e19e1115.js";export{t as component};
